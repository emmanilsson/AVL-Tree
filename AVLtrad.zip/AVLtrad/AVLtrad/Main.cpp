#include "AVLTree.h"
#include <iostream>
#include <stdlib.h>
#include "AVLTree.h"
#include <limits>
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>


int main()
{
	AVLTree <int> tree;

	tree.insert(0);
	tree.insert(5);
	tree.insert(3);
	tree.insert(41);
	tree.insert(61);
	tree.insert(-6);
	tree.insert(-1);
	tree.insert(-71);
	tree.insert(-12);
	tree.insert(-51);
	tree.insert(1);
	tree.insert(51);
	tree.insert(-15);

	tree.remove(-15);


	std::cout << "\nSurvived find: " << tree.find(5) << std::endl;



/*	try {
		tree.remove(7);
		tree.remove(7);
		tree.remove(7);
		tree.remove(180);
		tree.remove(7);
	}
	catch (const std::exception & e) {

		std::cout << e.what() << std::endl;
	}
/*


/*	try {
		tree.insert(10);
		tree.insert(10);
		tree.insert(10);
		tree.insert(10);
		tree.insert(10);
		tree.insert(10);
	}
	catch (const std::exception & e) {

		std::cout << e.what() << std::endl;
	}
*/

	

	
	std::cout << "Survived insert\n";

	
	
	//std::cout << "Survived remove\n";

	std::cout << "Survived inorder: ";
	tree.inOrderWalk();

	

	std::cout << "Survived getTreeHeight: ";

	// std::cout << std::numeric_limits<size_t>::max() << std::endl;
	std::cout << tree.getTreeHeight();
	

	std::cout << "\nSurvived find: " << tree.find(6) << std::endl;
	
	//std::cout << "Survived display" << std::endl;
	//node.display();

	std::cout << "Survived postOrderWalk\n";
	tree.postOrderWalk();
	//std::cout << "Survived getTreeHeight" << node.getTreeHeight();


	std::cout << "Survived inOrderWalk";
	tree.inOrderWalk();

	std::cout << "\nSurvived preOrderWalk";
	tree.preOrderWalk();


	std::cout << "Survived getMin: " << tree.getMin() <<  std::endl;
	
/*
	try {
		node.getMin();

	}
	catch (const std::exception & e) {

		std::cout << e.what() << std::endl;
	}
*/

	//std::cout << "Survived getMax: " << tree.getMax() << std::endl;


/*
	try {
		node.getMax();

	}
	catch (const std::exception & e) {

		std::cout << e.what() << std::endl;
	}

	//node.postorder();

*/
	system("pause");

	return 0;
}