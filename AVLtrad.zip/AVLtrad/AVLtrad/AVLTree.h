#ifndef AVLTREE_H
#define AVLTREE_H

#include <memory>
#include <cstdlib>
#include <exception>
#include <stdexcept>
#include <utility>
#include <iterator>
#include <vector>

using namespace std;


template <typename T>
class AVLTree
{
	struct Node
	{
		size_t height;
		T item;
		Node* left;
		Node* right;
	};


	Node* root;


	Node* insert(T element, Node* node)
	{

		if (node == NULL)
		{
			//G�r en ny nod
			node = new Node;
			node->item = element;
			node->height = 0;
			node->right = NULL;
			node->left = NULL;
		}
		else if (element < node->item)
		{
			//Om det inskickade elementet �r mindre �n node's item (root skickas in f�rsta g�ngen)
			//node->left blir det v�nstra elementet till node
			node->left = insert(element, node->left);


			//Tr�det �r obalanserat om h�jdskillnaden �r mer �n 1
			//Kollar allts� balanskravet och g�r is�fall en enkel eller dubberotation till h�ger
			if (height(node->left) - height(node->right) == 2)
			{
				if (element < node->left->item)
					node = rightRotate(node);
				else
					node = doubleRightRotate(node);
			}
		}
		else if (element > node->item)
		{
			//L�gg det nya elementet till h�ger om noden om det �r st�rre �n noden
			node->right = insert(element, node->right);
			if (height(node->right) - height(node->left) == 2)
			{
				if (element > node->right->item)
					node = leftRotate(node);
				else
					node = doubleLeftRotate(node);
			}
		}
		else
		{
			//Om det inskickade elementet redan finns i tr�det
			throw std::out_of_range("Duplicate values is not allowed in AVL Trees");
		}


		//J�mf�r h�jden p� node->left och node->right och returnera det st�rsta eller det f�rsta om de �r samma
		if (height(node->left) > height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) == height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) < height(node->right))
		{
			node->height = height(node->right) + 1;
		}


		return node;
	}

	Node* rightRotate(Node*& node)
	{
		Node* temp = node->left;
		node->left = temp->right;
		temp->right = node;


		if (height(node->left) > height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) == height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) < height(node->right))
		{
			node->height = height(node->right) + 1;
		}


		if ((height(temp->left)) > (node->height))
		{
			temp->height = height(temp->left) + 1;
		}
		else if ((height(temp->left)) == ((node->height)))
		{
			temp->height = height(temp->left) + 1;
		}
		else if ((height(node->left)) < (node->height))
		{
			temp->height = node->height + 1;
		}


		return temp;
	}

	Node* leftRotate(Node*& node)
	{
		Node* temp = node->right;
		node->right = temp->left;
		temp->left = node;


		//Uppdatera h�jden f�r noden
		if (height(node->left) > height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) == height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) < height(node->right))
		{
			node->height = height(node->right) + 1;
		}


		// Uppdatera h�jden f�r den nya roten
		if (height(node->right) > node->height)
		{
			temp->height = height(node->right) + 1;
		}
		else if (height(node->right) == (node->height))
		{
			temp->height = height(node->right) + 1;
		}
		else if (height(node->right) < node->height)
		{
			temp->height = node->height + 1;
		}


		return temp;
	}

	Node* doubleLeftRotate(Node*& node)
	{
		//G�r en v�nster dubbelrotation, dvs f�rst en enkel h�ger rotation sedan en enkel v�nster rotation
		node->right = rightRotate(node->right);
		return leftRotate(node);
	}

	Node* doubleRightRotate(Node*& node)
	{
		node->left = leftRotate(node->left);
		return rightRotate(node);
	}

	Node* compareForMin(Node* node)
	{
		if (node == NULL)
			return NULL;
		else if (node->left == NULL)
			return node;
		else
			return compareForMin(node->left);
	}

	bool findElement(T element, Node * treeRoot)
	{
		bool foundElem = true;

		if (treeRoot == NULL)
		{
			foundElem = false;

		}
		else if (element == treeRoot->item)
		{
			foundElem = true;
		}
		else if (element < treeRoot->item)
		{
			return findElement(element, treeRoot->left);
		}
		else if (treeRoot->item < element)
		{
			return findElement(element, treeRoot->right);
		}

		return foundElem;
	}

	bool findElement(T element)
	{
		if (findElement(element, root)) {
			return true;
		}
		else
			return false;
	}


	int getLevel(Node * node)
	{
		int level = height(node->left) - height(node->right);

		if (node == NULL)
			return 0;

		return level;
	}


	Node* remove(T element, Node * node)
	{

		Node* temp;

		if (node == NULL)
		{
			throw std::out_of_range("Cannot remove element not found");
		}


		//Om elementet �r mindre �n nodens item s� ligger elementet v�nster om node
		else if (element < node->item)
			node->left = remove(element, node->left);


		//Om elementet �r st�rre �n nodens item s� ligger elementet h�ger om node
		else if (element > node->item)
			node->right = remove(element, node->right);

		//G�r in i else if om elementet �r hittat och noden har tv� barn
		else if (node->left && node->right)
		{
			temp = compareForMin(node->right);
			node->item = temp->item;
			node->right = remove(node->item, node->right);
		}
		// else om noden har en eller tv� barn
		else
		{
			temp = node;
			if (node->left == NULL)
				node = node->right;
			else if (node->right == NULL)
				node = node->left;
			delete temp;
		}
		//Returnera om tr�det bara en rot nod
		if (node == NULL)
			return node;



		if (height(node->left) > height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) == height(node->right))
		{
			node->height = height(node->left) + 1;
		}
		else if (height(node->left) < height(node->right))
		{
			node->height = height(node->right) + 1;
		}



		int level = getLevel(node);

		// Olika scenarier om noden �r obalanserad
		// Nedanst�ende kod finns till f�r att "auto balansera" tr�det


		// V�nster v�nster 
		if (level > 1 && getLevel(node->left) >= 0)
			return rightRotate(node);

		// V�nster h�ger
		if (level > 1 && getLevel(node->left) < 0)
		{
			node->left = leftRotate(node->left);
			return rightRotate(node);
		}

		// H�ger h�ger  
		if (level < -1 && getLevel(node->right) <= 0)
			return leftRotate(node);

		// H�ger v�nster
		if (level < -1 && getLevel(node->right) > 0)
		{
			node->right = rightRotate(node->right);
			return leftRotate(node);
		}

		return node;
	}


	int height(Node * node)
	{

		if (node == NULL)
		{
			return -1;
		}
		else
		{
			return static_cast<int>(node->height);
		}
	}


	size_t treeHeight(Node * node)
	{
		int emptyHeight = -1;

		if (node == NULL)
		{
			return static_cast<size_t>(emptyHeight);
		}
		else
		{
			return static_cast<size_t>(node->height);
		}
	}



	std::vector<T> preOrder(Node * node, std::vector<T> & preTree)
	{
		if (node != NULL)
		{
			preTree.push_back(node->item);
			preOrder(node->left, preTree);
			preOrder(node->right, preTree);


			return preTree;

		}
		else
		{
			return preTree;
		}
	}


	std::vector<T> inOrder(Node * node, std::vector<T> inTree)
	{
		if (node != NULL)
		{
			inTree.push_back(node->item);

			inOrder(node->left, inTree);
			inOrder(node->right, inTree);

			return inTree;
		}
		else
		{
			return inTree;
		}
	}


	void inOrderRecursive(Node * node, std::vector<T>inTree) {

		inTree.push_back(node->item);

		inOrder(node->left, inTree);
		std::cout << node->item << " ";
		inOrder(node->right, inTree);
	}


	std::vector<T> postOrder(Node * node, std::vector<T> & postTree)
	{
		if (node != NULL)
		{
			postOrder(node->left, postTree);
			postOrder(node->right, postTree);

			postTree.push_back(node->item);

			return postTree;
		}
		else
		{
			return postTree;
		}
	}


	T getMin(Node * treeRoot)
	{
		Node* present;
		present = treeRoot;

		if (treeRoot != NULL)
		{
			//Kolla noderna till v�nster s�l�nge de inte �r NULL/tar slut, f�r i ett AVL-tr�d �r de mindre v�rdena til v�nster
			while (present->left != NULL)
			{
				present = present->left;
			}
		}
		else
		{
			throw std::out_of_range("AVL tree is empty, no minimun value");
		}

		const T min = present->item;
		return min;
	}


	T getMax(Node * treeRoot)
	{
		Node* present;
		present = treeRoot;

		if (treeRoot != NULL)
		{
			//Kolla noderna till h�ger s�l�nge de inte �r NULL/tar slut, f�r i ett AVL-tr�d �r de st�rre v�rdena til h�ger
			while (present->right != NULL)
			{
				present = present->right;
			}
		}
		else
		{
			throw std::out_of_range("AVL tree is empty, no maximum value");
		}

		const T max = present->item;
		return max;
	}


	void freeTree(Node * node)
	{
		if (node != NULL)
		{
			freeTree(node->right);
			freeTree(node->left);
			delete node;
		}
		else
			return;
	}


	std::string ToGraphviz() // Member function of the AVLTree class
	{
		std::string toReturn = "";
		if (root) // root is a pointer to the root Node of the tree
		{
			std::string listOfNodes;
			std::string listOfConnections = std::string("\node\"Root\" -> ") + std::to_string(0) + std::string(";\n");
			toReturn += std::string("digraph {\n");
			size_t id = 0;
			ToGraphvizHelper(listOfNodes, listOfConnections, root, id);
			toReturn += listOfNodes;
			toReturn += listOfConnections;
			toReturn += std::string("}");
		}
		return std::move(toReturn);
	}

	void ToGraphvizHelper(std::string & listOfNodes, std::string & listOfConnections, Node * toWorkWith, size_t & uniqueID) // Member function of the AVLTree class
	{
		size_t myID = uniqueID;
		listOfNodes += std::string("\node") + std::to_string(myID) + std::string(" [label=\"") + std::to_string(toWorkWith->element) + std::string("\"];\n");
		if (toWorkWith->leftChild)
		{
			listOfConnections += std::string("\node") + std::to_string(myID) + std::string(" -> ") + std::to_string(uniqueID + 1) + std::string(" [color=blue];\n");
			ToGraphvizHelper(listOfNodes, listOfConnections, toWorkWith->leftChild, ++uniqueID);
		}
		else
		{
			listOfNodes += std::string("\node") + std::to_string(++uniqueID) + std::string(" [label=") + std::string("nill, style = invis];\n");
			listOfConnections += std::string("\node") + std::to_string(myID) + std::string(" -> ") + std::to_string(uniqueID) + std::string(" [ style = invis];\n");
		}

		if (toWorkWith->rightChild)
		{
			listOfConnections += std::string("\node") + std::to_string(myID) + std::string(" -> ") + std::to_string(uniqueID + 1) + std::string(" [color=red];\n");
			ToGraphvizHelper(listOfNodes, listOfConnections, toWorkWith->rightChild, ++uniqueID);
		}
		else
		{
			listOfNodes += std::string("\node") + std::to_string(++uniqueID) + std::string(" [label=") + std::string("nill, style = invis];\n");
			listOfConnections += std::string("\node") + std::to_string(myID) + std::string(" -> ") + std::to_string(uniqueID) + std::string(" [ style = invis];\n");
		}
	}


public:


	AVLTree()
	{
		root = NULL;
	}

	~AVLTree()
	{
		freeTree(root);
	}


	void insert(T element);
	void remove(T element);
	bool find(T element);
	std::vector<T> preOrderWalk();
	std::vector<T> inOrderWalk();
	std::vector<T> postOrderWalk();
	size_t getTreeHeight();
	T getMin();
	T getMax();

};


template <typename T>
void AVLTree<T>::insert(T element)
{
	root = insert(element, root);
}


template <typename T>
void AVLTree<T>::remove(T element)
{
	root = remove(element, root);
}

template <typename T>
bool AVLTree<T>::find(T element)
{
	findElement(element, root);

	return findElement(element);
}


template <typename T>
std::vector<T> AVLTree<T>::preOrderWalk()
{
	std::vector<T>preOrderTree;
	return preOrder(root, preOrderTree);
}


template <typename T>
std::vector<T> AVLTree<T>::inOrderWalk()
{
	std::vector<T> inTree;
	return inOrder(root, inTree);
}


template <typename T>
std::vector<T> AVLTree<T>::postOrderWalk()
{
	std::vector<T> postTree;
	return postOrder(root, postTree);
}


template <typename T>
size_t AVLTree<T>::getTreeHeight()
{
	return treeHeight(root);
}


template <typename T>
T AVLTree<T>::getMin()
{
	return getMin(root);
}


template <typename T>
T AVLTree<T>::getMax()
{
	return getMax(root);
}




#endif